const axios = require("axios")
exports.handler = function (event, context, callback) {
  console.log(event.body)
  console.log("terminal!")

  if (event.httpMethod !== "POST" || !event.body) {
    return {
      statusCode: 400,
      body: "",
    }
  }

  let payload

  try {
    payload = JSON.parse(event.body)
  } catch (error) {
    return {
      statusCode: 400,
      body: "",
    }
  }

  axios({
    method: "POST",
    url: `${process.env.CAREACADEMY_ENDPOINT}/v1/practitioners`,
    data: JSON.stringify(payload),
    auth: {
      username: process.env.CAREACADEMY_USERNAME,
      password: process.env.CAREACADEMY_PASSWORD,
    },
  })
    .then(() => {
      callback(null, {
        statusCode: 200,
        body: JSON.stringify({ success: true }),
      })
    })
    .then(() => {
      callback(null, {
        statusCode: 500,
        body: JSON.stringify({ error: true }),
      })
    })

  // callback(null, {
  //   statusCode: 200,
  //   body: JSON.stringify({
  //     fuck: "APIs",
  //   }),
  // })
}

// const fetch = require("node-fetch")
// import axios from "axios"

// exports.handler = async function (event, context) {
//   if (event.httpMethod !== "POST" || !event.body) {
//     return {
//       statusCode: 400,
//       body: "",
//     }
//   }
//
//   let payload
//
//   try {
//     payload = JSON.parse(event.body)
//   } catch (error) {
//     return {
//       statusCode: 400,
//       body: "",
//     }
//   }
//
//   axios({
//     method: "POST",
//     url: `${process.env.CAREACADEMY_ENDPOINT}/v1/practitioners`,
//     data: JSON.stringify(payload),
//     auth: {
//       username: process.env.CAREACADEMY_USERNAME,
//       password: process.env.CAREACADEMY_PASSWORD,
//     },
//   })
//     .then(() => {
//       callback(null, {
//         statusCode: 200,
//         body: JSON.stringify((success: true)),
//       })
//     })
//     .then(() => {
//       callback(null, {
//         statusCode: 500,
//         body: JSON.stringify((error: true)),
//       })
//     })
//
//   // try {
//   //   const create = await fetch(
//   //     `https://go.careacademy.com/api/v1/practitioners`,
//   //     {
//   //       method: "POST",
//   //       headers: {
//   //         "Content-Type": "application/json",
//   //         Authorization:
//   //           "Basic " +
//   //           btoa(
//   //             "5ee03033-5d0d-4b22-829a-ae8f5e224094:06b280c6-7106-42be-a9da-00dca4ece1ae"
//   //           ),
//   //       },
//   //       body: JSON.stringify(payload),
//   //     }
//   //   )
//   //   const body = await create.json()
//   //   return {
//   //     statusCode: 200,
//   //     body: JSON.stringify(body),
//   //   }
//   // } catch (error) {
//   //   console.log(error)
//   //   return {
//   //     statusCode: 500,
//   //     body: JSON.stringify({ message: "Successful" }),
//   //   }
//   // }
// }
